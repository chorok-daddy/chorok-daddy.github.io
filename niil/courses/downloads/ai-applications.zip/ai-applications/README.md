# 인공지능응용

[강의자료 열기](https://chorok-daddy.github.io/niil/courses/ai-applications/) · [과목 다운로드](https://chorok-daddy.github.io/niil/courses/downloads/ai-applications.zip)
