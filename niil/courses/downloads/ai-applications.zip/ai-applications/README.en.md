# AI Applications

[View course page](https://chorok-daddy.github.io/niil/en/courses/ai-applications/)

## Download

HTML notes, practice files and supporting materials.

[Download course materials](https://chorok-daddy.github.io/niil/courses/downloads/ai-applications.zip)

Extract the ZIP and open **index.html**. English practice files use `.en.ipynb` and `.en.mlx`.

<details>
<summary>Author & use</summary>

[Author and attribution](https://chorok-daddy.github.io/niil/en/courses/reuse.html) · [License](../LICENSE.md)

</details>
