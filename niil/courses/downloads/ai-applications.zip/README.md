# 인공지능응용

index.html을 여세요. 영어 실습 파일은 `.en.ipynb`·`.en.mlx`입니다.

[저자·이용 안내](reuse.html)
