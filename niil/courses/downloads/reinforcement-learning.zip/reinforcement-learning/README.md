# 전기공학을 위한 강화학습

[강의 페이지 보기](https://chorok-daddy.github.io/niil/courses/reinforcement-learning/)

## 다운로드

HTML 강의자료, 실습 파일과 보조자료를 포함합니다.

[과목 자료 다운로드](https://chorok-daddy.github.io/niil/courses/downloads/reinforcement-learning.zip)

압축을 풀고 루트의 **index.html**을 여세요.

<details>
<summary>저자·이용 안내</summary>

[저자 및 출처 표기](https://chorok-daddy.github.io/niil/courses/reuse.html) · [라이선스 전문](../LICENSE.md)

</details>
