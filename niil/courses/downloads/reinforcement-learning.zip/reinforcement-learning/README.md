# 전기공학을 위한 강화학습

[강의자료 열기](https://chorok-daddy.github.io/niil/courses/reinforcement-learning/) · [과목 다운로드](https://chorok-daddy.github.io/niil/courses/downloads/reinforcement-learning.zip)
