# 로봇기초실습

[강의자료 열기](https://chorok-daddy.github.io/niil/courses/robot-basic-lab/) · [과목 다운로드](https://chorok-daddy.github.io/niil/courses/downloads/robot-basic-lab.zip)
