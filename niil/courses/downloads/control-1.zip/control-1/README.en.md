# Control Engineering I

[View course page](https://chorok-daddy.github.io/niil/en/courses/control-1/)

## Download

HTML notes, practice files and supporting materials.

[Download course materials](https://chorok-daddy.github.io/niil/courses/downloads/control-1.zip)

Extract the ZIP and open **index.html**. English practice files use `.en.ipynb` and `.en.mlx`.

<details>
<summary>Author & use</summary>

[Author and attribution](https://chorok-daddy.github.io/niil/en/courses/reuse.html) · [License](../LICENSE.md)

</details>
