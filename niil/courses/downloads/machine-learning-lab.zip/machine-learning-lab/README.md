# 전기공학머신러닝실습

[강의자료 열기](https://chorok-daddy.github.io/niil/courses/machine-learning-lab/) · [과목 다운로드](https://chorok-daddy.github.io/niil/courses/downloads/machine-learning-lab.zip)
