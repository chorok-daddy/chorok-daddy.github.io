# 전기공학머신러닝실습

[강의 페이지 보기](https://chorok-daddy.github.io/niil/courses/machine-learning-lab/)

## 다운로드

HTML 강의자료, 실습 파일과 보조자료를 포함합니다.

[과목 자료 다운로드](https://chorok-daddy.github.io/niil/courses/downloads/machine-learning-lab.zip)

압축을 풀고 루트의 **index.html**을 여세요.

<details>
<summary>저자·이용 안내</summary>

[저자 및 출처 표기](https://chorok-daddy.github.io/niil/courses/reuse.html) · [라이선스 전문](../LICENSE.md)

</details>
