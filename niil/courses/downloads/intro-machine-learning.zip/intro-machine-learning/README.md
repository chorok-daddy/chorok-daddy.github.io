# 머신러닝의 이해

[강의자료 열기](https://chorok-daddy.github.io/niil/courses/intro-machine-learning/) · [과목 다운로드](https://chorok-daddy.github.io/niil/courses/downloads/intro-machine-learning.zip)
