# 마이크로프로세서응용설계

[강의자료 열기](https://chorok-daddy.github.io/niil/courses/microprocessor/) · [과목 다운로드](https://chorok-daddy.github.io/niil/courses/downloads/microprocessor.zip)
